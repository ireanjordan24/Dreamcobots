This package contains bot logic for DreamCo AI project.
Each file is standalone but designed to work in sync.