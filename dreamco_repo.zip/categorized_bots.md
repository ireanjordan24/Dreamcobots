## Categorized Bots
Placeholder.
