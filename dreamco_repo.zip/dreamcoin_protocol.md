## DreamCoin Protocol
Protocol details.
