## DreamCo Architecture
High-level architecture.
