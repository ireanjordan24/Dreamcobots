This folder contains the Android Version of DreamCo.
Instructions: Drag and drop into your respective platform or follow instructions provided.
