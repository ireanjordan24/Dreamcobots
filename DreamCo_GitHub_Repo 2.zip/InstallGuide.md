### DreamCo Install Guide
1. Clone or download this repo.
2. Open DreamCo Launcher.
3. All bots and systems will auto-activate.
